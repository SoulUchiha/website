<?php namespace Common\Billing;

use Exception;

class GatewayException extends Exception {

}