<?php

use Common\Pages\LoadCustomPageMenuItems;

return [
    [
        'name' => 'Custom Pages',
        'itemsLoader' => LoadCustomPageMenuItems::class,
    ]
];